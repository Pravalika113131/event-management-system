# Vibow ELIST Registration App

A Flask-based group registration platform for Vibow Tech Fest, supporting multiple participants, file uploads, and SQLite database.

---

## Features

- Group registration (adults/kids) with individual participant details
- Payment screenshot upload (stored securely)
- Unique confirmation ID for each group
- SQLite backend (auto-initialized)
- Ready for deployment on [Render](https://render.com/)

---

## Local Development

1. **Clone the repo:**
    ```bash
    git clone https://github.com/yourusername/elist.git
    cd elist
    ```

2. **Set up a Python virtual environment (optional but recommended):**
    ```bash
    python -m venv venv
    source venv/bin/activate
    ```

3. **Install dependencies:**
    ```bash
    pip install -r requirements.txt
    ```

4. **Run the app:**
    ```bash
    python app.py
    ```
    The app will start on [http://localhost:5000](http://localhost:5000).

---

## Deployment on Render

1. **Push your code to GitHub.**
2. **Create a new Web Service on [Render](https://render.com/).**
3. **Connect your repository.**
4. **Ensure your `render.yaml` exists:**
    ```yaml
    services:
      - type: web
        name: vibow-elist
        env: python
        buildCommand: ""
        startCommand: gunicorn app:app
        envVars:
          - key: FLASK_ENV
            value: production
        autoDeploy: true
        plan: free
    ```
5. **Deploy!**

- Render runs your app with `gunicorn app:app`.
- SQLite DB and uploads are stored in `/tmp` (ephemeral; reset on every deploy).

---

## API Endpoints

- `POST /api/register-group` — Register a group with participants and payment screenshot.
- `GET /uploads/<filename>` — Access uploaded screenshots.

---

## Notes

- For local development, uploads and DB are in the project folder.
- On Render, uploads and DB are in `/tmp` (auto-created).
- Static HTML files are served for the frontend.
- No `Procfile` needed for Render!

---

## License

MIT License